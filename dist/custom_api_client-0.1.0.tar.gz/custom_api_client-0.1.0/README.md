# Weather API Client

A Python client for interacting with the OpenWeatherMap API.

## Installation

Install the package using pip:
